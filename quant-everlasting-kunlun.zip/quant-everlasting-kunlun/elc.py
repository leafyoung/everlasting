from typing import Literal

import numpy as np
from scipy.stats import norm


class BS:
    @staticmethod
    def d1(S, K, sigma, T, r=0.0):
        d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
        return d1

    @staticmethod
    def d2(S, K, sigma, T, r=0.0):
        d2 = BS.d1(S, K, sigma, T, r) - np.sqrt(T) * sigma
        return d2

    @staticmethod
    def call(S, K, sigma, T, r=0.0):
        return S * norm.cdf(BS.d1(S, K, sigma, T, r)) - K * np.exp(-r * T) * norm.cdf(
            BS.d2(S, K, sigma, T, r)
        )

    @staticmethod
    def put(S, K, sigma, T, r=0.0):
        return -S * norm.cdf(-BS.d1(S, K, sigma, T, r)) + K * np.exp(-r * T) * norm.cdf(
            -BS.d2(S, K, sigma, T, r)
        )

    @staticmethod
    def delta(S, K, sigma, T, option: Literal["call", "put"], r=0.0):
        if option == "call":
            return norm.cdf(BS.d1(S, K, sigma, T, r))
        elif option == "put":
            return norm.cdf(BS.d1(S, K, sigma, T, r)) - 1
        raise ValueError("option must be either 'call' or 'put'")

    @staticmethod
    def gamma(S, K, sigma, T, r=0.0):
        return norm.pdf(BS.d1(S, K, sigma, T, r)) / (S * sigma * np.sqrt(T))

    @staticmethod
    def vega(S, K, sigma, T, r=0.0):
        return S * norm.pdf(BS.d1(S, K, sigma, T, r)) * np.sqrt(T)


class ELC:
    @staticmethod
    def replace_SK(S, K, V1, V2):
        if isinstance(S < K, np.ndarray):
            V_sel = S < K
            if V1[V_sel].size > 0:
                V1[V_sel] = V2[V_sel]
            return V1
        if S < K:
            return V2
        return V1

    @staticmethod
    def u(T, sigma):
        return np.sqrt(1 + 8 / sigma / sigma / (T / 365))

    @staticmethod
    def V(T, S, K, sigma):
        u = ELC.u(T, sigma)
        return ELC.replace_SK(
            S,
            K,
            K / u * np.pow(S / K, -(u - 1) / 2),
            K / u * np.pow(S / K, (u + 1) / 2),
        )

    @staticmethod
    def call(T, S, K, sigma):
        result = ELC.V(T, S, K, sigma) + np.maximum(S - K, 0)
        return result

    @staticmethod
    def put(T, S, K, sigma):
        result = ELC.V(T, S, K, sigma) + np.maximum(K - S, 0)
        return result

    @staticmethod
    def delta(T, S, K, sigma):
        u = ELC.u(T, sigma)
        V = ELC.V(T, S, K, sigma)
        # -(u - 1) / (2 * S) * V + 1
        return ELC.replace_SK(S, K, -(u - 1) / (2 * S) * V + 1, (u + 1) / 2 / S * V)
        # return -(u - 1) / 2 / u * np.power(S / K, -(u + 1) / 2) + 1
        # or, return -(u - 1) / 2 / S * V + 1 # S >= K
        # return (u + 1) / 2 / u * np.power(S / K, (u - 1) / 2)
        # or, return (u + 1) / 2 / S * V # S < K

    @staticmethod
    def gamma(T, S, K, sigma):
        V = ELC.V(T, S, K, sigma)
        # eq alt.
        # _u = ELC.u(T, sigma)
        # return 1.0 / 4 * (_u * _u - 1) / S / S * V
        return 2.0 / sigma / sigma / (T / 365) * V / S / S

    @staticmethod
    def vega(T, S, K, sigma):
        u = ELC.u(T, sigma)
        V = ELC.V(T, S, K, sigma)
        return ELC.replace_SK(
            S,
            K,
            (1 + u / 2 * np.log(S / K)) * (1 - 1.0 / u / u) * V / sigma,
            (1 - u / 2 * np.log(S / K)) * (1 - 1.0 / u / u) * V / sigma,
        )


class EL:
    @staticmethod
    def replicate(T, F, S, K, sigma, N=1000):
        unit_r = F / (F + 1)
        unit_t = T / F
        index = np.arange(1, N + 1)
        time = index * unit_t
        # Weight: Because, E(T) converge to T when F approaches infinity, we normalize with 1/T.
        weight = np.power(unit_r, index) * unit_t / T
        sum_weight = np.cumsum(weight)
        try:
            assert np.isclose(sum_weight[-1], 1, 0.0001)
        except AssertionError:
            print(sum_weight[-1])
            raise

        weighted_time = time * weight
        sum_weighted_time = np.cumsum(weighted_time)
        call_price = BS.call(S, K, sigma, time / 365)
        weighted_call_price = call_price * weight
        sum_weighted_call_price = np.cumsum(weighted_call_price)

        put_price = BS.put(S, K, sigma, time / 365)
        weighted_put_price = put_price * weight
        sum_weighted_put_price = np.cumsum(weighted_put_price)

        # * F because we will have multiple of payments
        cf_call = (
            weighted_call_price[0]
            + sum(call_price[1:] * (weight[:-1] - weight[1:])) * F
        )
        cf_put = (
            weighted_put_price[0] + sum(put_price[1:] * (weight[:-1] - weight[1:])) * F
        )

        series1 = sum(weight[:-1] * call_price[1:]) * F
        series2 = (1 + F) * sum(weight[1:] * call_price[1:])

        return (
            sum_weighted_time[-1],
            sum_weighted_call_price[-1],
            sum_weighted_put_price[-1],
            np.stack([time, weight]),
            cf_call,
            cf_put,
            series1,
            series2,
        )


def _validate():
    # print(
    #     ELC.call(1, 20000, 20000, np.array([0.8, 0.6])),
    #     ELC.call(1, 20000, 20000, 0.8),
    #     ELC.call(1, 20000, 18000, 0.6),
    #     ELC.call(1, 20000, 22000, 0.6),
    #     ELC.put(1, 20000, 20000, np.array([0.8, 0.6])),
    #     ELC.put(1, 20000, 20000, 0.8),
    #     ELC.put(1, 20000, 22000, 0.6),
    #     ELC.put(1, 20000, 18000, 0.6),
    # )

    for K in [20000, 22000, 18000]:
        pair = (
            ELC.call(1, 20000, K, 0.6) - ELC.put(1, 20000, K, 0.6),
            20000 - K,
        )
        # print(*pair)
        assert np.isclose(*pair)

    delta_p3, vega_p2, delta, gamma, vega = (
        ELC.call(1, np.array([19999.99, 20000, 20000.01]), 20000, 0.8),
        ELC.call(1, 20000, 20000, np.array([0.79, 0.8, 0.81])),
        ELC.delta(1, 20000, 20000, 0.8),
        ELC.gamma(1, 20000, 20000, 0.8),
        ELC.vega(1, 20000, 20000, 0.8),
    )
    try:
        assert np.isclose(delta, (delta_p3[2] - delta_p3[0]) / 0.02)
    except AssertionError:
        print(delta, (delta_p3[2] - delta_p3[0]) / 0.02)
        raise

    assert np.isclose(
        gamma, (delta_p3[2] - 2 * delta_p3[1] + delta_p3[0]) / 0.01 / 0.01
    )
    assert np.isclose(vega, (vega_p2[2] - vega_p2[0]) / 0.02)

    _wtime, wcall, wput, _time_weight, mcall, mput, series1, series2 = EL.replicate(
        2, 10, 20000, 20000, 0.8, 1000
    )
    assert np.isclose(wcall, wput, atol=1e-5)
    assert np.isclose(mcall, mput, atol=1e-5)
    assert np.isclose(series1, series2, atol=1e-5)

    for K in [20000, 22000, 18000]:
        (
            wtime,
            wcall,
            wput,
            _time_weight,
            mcall,
            mput,
            series1,
            series2,
        ) = EL.replicate(2, 100000, 20000, K, 0.8, 3000000)

        try:
            assert np.isclose(wcall, mcall, atol=1e-5)
            assert np.isclose(wput, mput, atol=1e-5)
            assert np.isclose(wtime, 2.0, atol=1e-5)
            assert np.isclose(series1, series2, atol=1e-5)
        except AssertionError:
            print(wcall, wput)
            print(mcall, mput)
            print(wtime)
            raise
        ccall = ELC.call(2, 20000, K, 0.8)
        cput = ELC.put(2, 20000, K, 0.8)
        try:
            assert np.isclose(wcall, ccall, atol=1e-3)
            assert np.isclose(wput, cput, atol=1e-3)
        except AssertionError:
            print(wcall, ccall)
            print(wput, cput)
            raise

    # Same T and N shall give same time_weight and time1
    _wtime1, _, _, _time_weight1, _, _, _, _ = EL.replicate(
        2, 10, 20000, 21000, 0.8, 1000
    )
    _wtime2, _, _, _time_weight2, _, _, _, _ = EL.replicate(
        2, 10, 21000, 20000, 0.8, 1000
    )
    assert np.allclose(_time_weight1, _time_weight2)
    assert np.isclose(_wtime1, _wtime2)
